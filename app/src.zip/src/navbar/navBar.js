(function(){
  'use strict';

  // Prepare the 'navBar' module for subsequent registration of controllers and delegates
  angular.module('navBar', [ 'ngMaterial' ]);


})();
