(function(){
  'use strict';

  // Prepare the 'sideNavBar' module for subsequent registration of controllers and delegates
  angular.module('sideNavBar', [ 'ngMaterial' , 'ngMdIcons']);


})();
